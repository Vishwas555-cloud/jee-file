// app/mock-test/[slug]/page.tsx
"use client";

import React, { useEffect, useState, useCallback } from "react";
import ExamQuestion from "@/components/ExamQuestion";
import Loader from "@/components/ui/loader";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useRouter } from "next/navigation";
import { Timer } from "lucide-react";

interface Question {
  qid: string;
  question_number: number;
  question_value: {
    text: string | null;
    img_url: string;
  };
  options: {
    [key: string]: string | { text: string | null; img_url: string } | undefined;
  };
  correct_answer: number;
  solution?: string;
}

interface UserAnswer {
  questionId: string;
  selectedOption: number | null;
  isCorrect: boolean;
  isMarked: boolean;
}

export default function Page({ params }: { params: { slug: string } }) {
  const [examData, setExamData] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<UserAnswer[]>([]);
  const [timeLeft, setTimeLeft] = useState(180 * 60); // 180 minutes in seconds
  const [isSubmitted, setIsSubmitted] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetchData();
  }, [params.slug]);

  useEffect(() => {
    if (examData.length > 0 && userAnswers.length === 0) {
      const initialAnswers = examData.map((question) => ({
        questionId: question.qid,
        selectedOption: null,
        isCorrect: false,
        isMarked: false,
      }));
      setUserAnswers(initialAnswers);
    }
  }, [examData]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  async function fetchData() {
    try {
      const response = await fetch(`/sqp/${params.slug}.json`);
      if (response.ok) {
        const data = await response.json();
        setExamData(data);
      } else {
        console.error("Failed to fetch data:", response.status);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  const handleOptionSelect = useCallback((questionId: string, selectedOption: number) => {
    setUserAnswers(prevAnswers =>
      prevAnswers.map(answer =>
        answer.questionId === questionId
          ? {
              ...answer,
              selectedOption,
              isCorrect: examData.find(q => q.qid === questionId)?.correct_answer === selectedOption,
            }
          : answer
      )
    );
  }, [examData]);

  const handleMarkForReview = useCallback((questionId: string) => {
    setUserAnswers(prevAnswers =>
      prevAnswers.map(answer =>
        answer.questionId === questionId
          ? { ...answer, isMarked: !answer.isMarked }
          : answer
      )
    );
  }, []);

  const handleClearResponse = useCallback((questionId: string) => {
    setUserAnswers(prevAnswers =>
      prevAnswers.map(answer =>
        answer.questionId === questionId
          ? { ...answer, selectedOption: null, isCorrect: false }
          : answer
      )
    );
  }, []);

  const handleSubmit = () => {
    setIsSubmitted(true);
  };

  const calculateResults = () => {
    const totalQuestions = examData.length;
    const attempted = userAnswers.filter(a => a.selectedOption !== null).length;
    const correct = userAnswers.filter(a => a.isCorrect).length;
    const incorrect = attempted - correct;
    const score = correct * 4 - incorrect * 1; // Assuming +4 for correct, -1 for incorrect
    const accuracy = attempted > 0 ? Math.round((correct / attempted) * 100) : 0;
    
    return {
      totalQuestions,
      attempted,
      correct,
      incorrect,
      score,
      accuracy,
    };
  };

  if (isSubmitted) {
    const results = calculateResults();
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Test Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div className="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
                <h3 className="font-bold">Total Questions</h3>
                <p className="text-2xl">{results.totalQuestions}</p>
              </div>
              <div className="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg">
                <h3 className="font-bold">Attempted</h3>
                <p className="text-2xl">{results.attempted}</p>
              </div>
              <div className="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
                <h3 className="font-bold">Correct</h3>
                <p className="text-2xl">{results.correct}</p>
              </div>
              <div className="bg-red-100 dark:bg-red-900 p-4 rounded-lg">
                <h3 className="font-bold">Incorrect</h3>
                <p className="text-2xl">{results.incorrect}</p>
              </div>
              <div className="bg-purple-100 dark:bg-purple-900 p-4 rounded-lg">
                <h3 className="font-bold">Score</h3>
                <p className="text-2xl">{results.score}</p>
              </div>
              <div className="bg-yellow-100 dark:bg-yellow-900 p-4 rounded-lg">
                <h3 className="font-bold">Accuracy</h3>
                <p className="text-2xl">{results.accuracy}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-bold">Solutions</CardTitle>
          </CardHeader>
          <CardContent>
            {examData.map((question, index) => {
              const userAnswer = userAnswers.find(a => a.questionId === question.qid);
              return (
                <div key={question.qid} className="mb-8 border-b pb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-bold">Q{index + 1}:</span>
                    {userAnswer?.isCorrect ? (
                      <span className="text-green-500">✓ Correct</span>
                    ) : (
                      <span className="text-red-500">✗ Incorrect</span>
                    )}
                    {userAnswer?.isMarked && (
                      <span className="text-yellow-500">⭐ Marked</span>
                    )}
                  </div>
                  <ExamQuestion
                    key={question.qid}
                    QuestionId={question.qid}
                    Question={question.question_value}
                    QuestionNumber={question.question_number}
                    Options={question.options || {}}
                    CorrectAnswer={question.correct_answer}
                    showSolution
                    userAnswer={userAnswer?.selectedOption}
                  />
                  {question.solution && (
                    <div className="mt-4 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                      <h4 className="font-bold mb-2">Solution:</h4>
                      <p>{question.solution}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (examData.length === 0) {
    return (
      <div className="min-h-screen flex justify-center items-center overscroll-none">
        <Loader TextValue=" is Loading..." />
      </div>
    );
  }

  const currentQuestion = examData[currentQuestionIndex];
  const currentUserAnswer = userAnswers.find(a => a.questionId === currentQuestion.qid);

  return (
    <div className="container mx-auto px-4 py-4">
      <Card className="mb-4">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <CardTitle>Question {currentQuestionIndex + 1} of {examData.length}</CardTitle>
            <div className="flex items-center gap-2">
              <Timer className="h-5 w-5" />
              <span>
                {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Progress 
            value={(currentQuestionIndex + 1) / examData.length * 100} 
            className="h-2"
          />
        </CardContent>
      </Card>

      <ExamQuestion
        key={currentQuestion.qid}
        QuestionId={currentQuestion.qid}
        Question={currentQuestion.question_value}
        QuestionNumber={currentQuestion.question_number}
        Options={currentQuestion.options || {}}
        CorrectAnswer={currentQuestion.correct_answer}
        onOptionSelect={handleOptionSelect}
        userAnswer={currentUserAnswer?.selectedOption ?? null}
        showSolution={false}
      />

      <div className="flex flex-wrap gap-2 justify-between mt-4">
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => handleMarkForReview(currentQuestion.qid)}
            className={currentUserAnswer?.isMarked ? "bg-yellow-500 text-white" : ""}
          >
            {currentUserAnswer?.isMarked ? "Unmark Review" : "Mark for Review"}
          </Button>
          <Button 
            variant="outline" 
            onClick={() => handleClearResponse(currentQuestion.qid)}
          >
            Clear Response
          </Button>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            disabled={currentQuestionIndex === 0}
            onClick={() => setCurrentQuestionIndex(prev => Math.max(0, prev - 1))}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            disabled={currentQuestionIndex === examData.length - 1}
            onClick={() => setCurrentQuestionIndex(prev => Math.min(examData.length - 1, prev + 1))}
          >
            Next
          </Button>
          <Button
            variant="default"
            onClick={handleSubmit}
          >
            Submit Test
          </Button>
        </div>
      </div>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Question Navigation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
            {examData.map((_, index) => {
              const answer = userAnswers[index];
              let bgColor = "bg-gray-200 dark:bg-gray-700";
              if (answer?.selectedOption !== null) {
                bgColor = answer?.isCorrect ? "bg-green-500" : "bg-red-500";
              }
              if (answer?.isMarked) {
                bgColor = "bg-yellow-500";
              }
              return (
                <Button
                  key={index}
                  variant="outline"
                  className={`w-10 h-10 p-0 ${bgColor} ${
                    currentQuestionIndex === index ? "ring-2 ring-blue-500" : ""
                  }`}
                  onClick={() => setCurrentQuestionIndex(index)}
                >
                  {index + 1}
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}