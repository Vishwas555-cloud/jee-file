export const OtherExams = [
  {
    Title: "Bitsat 2022",
    RedirectValue: "bitsat-2022",
    Day: true,
  },
  {
    Title: "Neet 2022 , May 7",
    RedirectValue: "neet-2023",
    Day: true,
  },
  {
    Title: "Jee Advance 2023",
    RedirectValue: "jee-advance-2023",
    Day: true,
  },
  {
    Title: "Comedk 2023",
    RedirectValue: "comedk-2023",
    Day: true,
  },
  {
    Title: "MHT-CET 2023",
    RedirectValue: "mht-cet-2023",
    Day: true,
  },
];

export const Jee = [
  {
    Title: "27th Shift 1 Morning",
    RedirectValue: "27s1",
    Day: true,
  },
  {
    Title: "29th Shift 1 Morning",
    RedirectValue: "29s1",
    Day: true,
  },
  {
    Title: "30th Shift 1 Morning",
    RedirectValue: "30s1",
    Day: true,
  },
  {
    Title: "31th Shift 1 Morning",
    RedirectValue: "31s1",
    Day: true,
  },
  {
    Title: "1st Shift 1 Morning",
    RedirectValue: "1s1",
    Day: true,
  },
  {
    Title: "27th Shift 2 Evening",
    RedirectValue: "27s2",
    Day: false,
  },
  {
    Title: "29th Shift 2 Evening",
    RedirectValue: "29s2",
    Day: false,
  },
  {
    Title: "30th Shift 2 Evening",
    RedirectValue: "30s2",
    Day: false,
  },
  {
    Title: "31th Shift 2 Evening",
    RedirectValue: "31s2",
    Day: false,
  },
  {
    Title: "1st Shift 2 Evening",
    RedirectValue: "1s2",
    Day: false,
  },
];
