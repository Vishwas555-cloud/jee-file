// components/NumericalBox.tsx
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface NumericalBoxProps {
  RightAns: number;
  userAnswer ? : number | null;
  showSolution ? : boolean;
}

export function NumericalBox({ RightAns, userAnswer = null, showSolution = false }: NumericalBoxProps) {
  const [NumValue, setNumValue] = useState < number | "" > (userAnswer !== null ? userAnswer : "");
  const [checkNow, setcheckNow] = useState(false);
  const [isRight, setisRight] = useState(false);
  
  const handleSubmit = () => {
    setcheckNow(true);
    if (NumValue === RightAns) {
      setisRight(true);
    } else {
      setisRight(false);
    }
  };
  
  if (showSolution && userAnswer !== null) {
    return (
      <div className="my-4">
        <div className="flex items-center space-x-2">
          <Input
            type="number"
            placeholder="Enter your answer :"
            className="sm:w-5/9 lg:w-full"
            value={userAnswer}
            readOnly
          />
        </div>
        <div className="mt-2">
          {userAnswer === RightAns ? (
            <h1 className="text-green-400 text-xl font-bold px-2 py-2">Correct Answer</h1>
          ) : (
            <h1 className="text-red-400 font-bold px-1 py-1">
              Wrong, <span className="text-green-400">The Right Answer is: "{RightAns}"</span>
            </h1>
          )}
        </div>
      </div>
    );
  }
  
  return (
    <div>
      <div className="flex items-center space-x-2">
        <Input
          type="number"
          placeholder="Enter your answer :"
          className="sm:w-5/9 lg:w-full"
          value={NumValue}
          onChange={(e) => {
            setNumValue(parseFloat(e.target.value) || "";
            setcheckNow(false);
          }}
        />
        <Button type="button" variant="ghost" className="w-2/3" onClick={handleSubmit}>
          Submit
        </Button>
      </div>
      {isRight ? (
        <h1 className="text-green-400 text-xl font-bold px-2 py-2">Correct Answer</h1>
      ) : (
        NumValue &&
        checkNow && (
          <h1 className="text-red-400 font-bold px-1 py-1">
            Wrong, <span className="text-green-400">The Right Answer is: "{RightAns}"</span>
          </h1>
        )
      )}
    </div>
  );
}